# CLAUDE.md — Demo Setup Instructions
## Automated Contrast Correction System
### COMP7116001 Computer Vision | Team 2 | Binus University

---

## Konteks Project
Ini adalah demo app untuk presentasi final project Computer Vision.
App berbasis Streamlit untuk koreksi kontras foto underexposed/overexposed
menggunakan GHE dan CLAHE dengan ML classifier dan parameter predictor.

**Stack:** Python, OpenCV, Streamlit, scikit-learn, scikit-image, matplotlib

---

## Tugas Utama: Jalankan App untuk Demo

### Langkah 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Langkah 2 — Jalankan app
```bash
python -m streamlit run app.py --server.port 8501 --browser.gatherUsageStats false
```

App buka otomatis di browser. Jika tidak, buka manual: http://localhost:8501

---

## Jika Ada Error

### Error: `ModuleNotFoundError`
Jalankan ulang install:
```bash
pip install -r requirements.txt
```

### Error: `cv2` tidak ditemukan
```bash
pip install opencv-python==4.9.0.80
```

### Error: port 8501 already in use
```bash
python -m streamlit run app.py --server.port 8502
```
Lalu buka http://localhost:8502

### Error: model `.pkl` tidak ditemukan
Pastikan folder `ml/models/` berisi tiga file:
- `exposure_classifier.pkl`
- `predictor_clip.pkl`
- `predictor_tile.pkl`

Jika hilang, minta file dari pemilik project (Rafifdiya - rafif.diya2301@gmail.com).

### App berjalan tapi lambat saat pertama upload
Normal — model ML di-load saat pertama kali dipakai. Setelah itu cepat.

---

## Struktur Folder (jangan ubah)
```
DEMO_PACKAGE/
├── app.py                  # Main Streamlit app — jangan edit
├── requirements.txt
├── .streamlit/config.toml  # UI config
├── processing/             # CV pipeline (GHE, CLAHE, metrics)
├── utils/                  # Plotting utilities
└── ml/
    ├── features.py         # Feature extractor
    ├── classifier.py       # Exposure classifier
    ├── predictor.py        # Parameter predictor
    └── models/             # Trained ML models (.pkl) — JANGAN HAPUS
```

---

## Cara Pakai App (untuk demo)
1. Upload foto underexposed atau overexposed
2. Sidebar → pilih mode **Auto (ML)**
3. Lihat label exposure otomatis + parameter CLAHE yang dipilih ML
4. Lihat 3 kolom hasil: Original | GHE | CLAHE
5. (Opsional) Upload ground truth untuk lihat PSNR & SSIM
6. Download hasil via tombol di bawah gambar

---

## Yang TIDAK perlu dilakukan
- Jangan training ulang model (sudah trained, tersimpan di ml/models/)
- Jangan install dataset (tidak dibutuhkan untuk demo)
- Jangan edit file apapun kecuali diminta

---

## Kontak jika butuh bantuan
Rafifdiya — rafif.diya2301@gmail.com
